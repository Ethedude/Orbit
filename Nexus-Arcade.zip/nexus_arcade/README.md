# NEXUS ARCADE

A self-contained browser gaming portal. No build step, package installation, server, or external game embeds are required for the built-in games.

## Run it

1. Download `index.html`.
2. Open it in a modern browser (Chrome, Edge, Firefox, or Safari).
3. Select **Games** and choose a game.

The page is responsive and also has mobile controls for selected games. Your title, tab icon, theme, scores, and play count are stored locally when the browser allows local storage.

## Included games

- Neon Snake
- 2048
- Minefield
- Memory Match
- Tic-Tac-Toe vs. computer
- Neon Pong vs. CPU
- Block Breaker
- Reaction Rush
- Tap Rush
- Simon Says
- Word Scramble
- Dodge Drop

## Browser panel

The Browser section is a lightweight embedded web viewer with search, an address field, navigation history, and quick links. It is not a proxy. Some websites intentionally prevent their pages from being embedded; use **New tab** to open those sites in a regular browser tab.

## About:blank launch and tab customization

Open **Settings** to set a tab title, choose an emoji favicon, and select an accent theme. **Launch blank tab** copies the arcade into a separate `about:blank` tab. The browser must allow pop-ups for the site. Some browsers or hosting environments restrict this feature.

## Hosting

To share the site, upload `index.html` to a static website host you control, such as a GitHub Pages project or another static host. The site has no backend. Follow the rules for the network and devices where you use it.
